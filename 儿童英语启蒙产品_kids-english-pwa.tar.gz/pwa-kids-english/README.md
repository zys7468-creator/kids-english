# 儿童英语启蒙 PWA 应用

## 📱 功能特点

- ✅ 字母学习：26个字母的认知、发音、练习
- ✅ 绘本阅读：多本互动绘本，支持朗读
- ✅ 儿歌牧场：经典英语儿歌
- ✅ 成就系统：学习成就激励
- ✅ 离线可用：添加到主屏幕后可离线使用
- ✅ 像APP一样运行：全屏、无浏览器界面

## 🚀 部署方式

### 方式一：本地测试

1. 下载整个 `pwa-kids-english` 文件夹
2. 用浏览器直接打开 `index.html`
3. 注意：某些浏览器本地打开时PWA功能可能受限

### 方式二：部署到服务器（推荐）

PWA 需要通过 HTTPS 或 localhost 访问才能正常工作。

#### 免费托管方案

**GitHub Pages：**
1. 创建 GitHub 账号
2. 创建新仓库，上传 `pwa-kids-english` 文件夹内容
3. 设置 → Pages → 选择 main 分支
4. 获得 `https://用户名.github.io/仓库名` 地址

**Vercel：**
1. 访问 vercel.com，用 GitHub 登录
2. 导入仓库，自动部署
3. 获得免费 HTTPS 域名

**Netlify：**
1. 访问 netlify.com
2. 直接拖拽文件夹上传
3. 获得免费 HTTPS 域名

## 📲 添加到主屏幕

### iPhone (Safari)
1. 用 Safari 打开应用网址
2. 点击底部分享按钮
3. 选择「添加到主屏幕」
4. 点击「添加」

### Android (Chrome)
1. 用 Chrome 打开应用网址
2. 点击右上角菜单
3. 选择「添加到主屏幕」或「安装应用」
4. 或等待底部弹出安装提示

### 电脑 (Chrome/Edge)
1. 打开应用网址
2. 点击地址栏右侧的安装图标（⊕）
3. 或菜单 → 更多工具 → 创建快捷方式

## 🔊 关于语音

- 使用浏览器内置的 Web Speech API
- 需要在系统浏览器中打开（不是微信/扣子内置浏览器）
- 首次打开需要点击「开始学习」解锁音频

## 📂 文件说明

```
pwa-kids-english/
├── index.html          # 主页面
├── manifest.json       # PWA配置文件
├── sw.js              # Service Worker（离线缓存）
├── icon-192.svg       # 小图标
├── icon-512.svg       # 大图标
├── icon-maskable.svg  # 适配图标
└── README.md          # 本说明文件
```

## 🛠 自定义修改

### 修改应用名称
编辑 `manifest.json` 中的 `name` 和 `short_name`

### 修改主题颜色
编辑 `manifest.json` 中的 `theme_color` 和 `background_color`

### 替换图标
1. 准备 192x192 和 512x512 的 PNG 图片
2. 替换对应的 SVG 文件，或修改 manifest 引用

### 添加内容
编辑 `index.html` 中的 `lettersData`、`booksData`、`songsData` 数组

## ⚠️ 注意事项

1. **必须 HTTPS**：PWA 功能需要 HTTPS 环境（localhost 除外）
2. **浏览器兼容**：推荐使用 Safari、Chrome、Edge
3. **语音权限**：部分浏览器可能需要授予语音权限
4. **iOS 限制**：iOS Safari 不支持自动弹出安装提示，需手动添加